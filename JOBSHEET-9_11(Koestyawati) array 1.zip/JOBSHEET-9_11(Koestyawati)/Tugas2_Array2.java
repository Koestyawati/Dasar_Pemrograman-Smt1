import java.util.Scanner;
public class Tugas2_Array2{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String cabang[] = new String[4];
        String jenisBuku[] = { "Novel", "Komik", "Pelajaran", "Ensiklopedia" };
        int buku[][] = new int[3][4];
        int k;
        int totalSemua[] = new int[3];
        int novel, komik, pelajaran, ensiklopedia, total, maxTotal;
        for (int i = 0; i < 3; i++){
            System.out.print("Masukkan lokasi cabang :");
            cabang[i] = sc.next();
            for (int j = 0; j < jenisBuku.length; j++){
                System.out.print("Masukkan jumlah buku " + jenisBuku[j] + " : ");
                buku[i][j] = sc.nextInt();
            }
            novel = buku[i][0] * 40000;
            komik = buku[i][1] * 28000;
            pelajaran = buku[i][2] * 60000;
            ensiklopedia = buku[i][3] * 75000;
            total = novel + komik + pelajaran + ensiklopedia;
            totalSemua[i] = total;
            System.out.println("Total penjualan buku = Rp." + total);
            System.out.println("-----------------------------------------------");
        }
        String cabangTertinggi=cabang[0] ;
        maxTotal = 0;
        for (k = 0; k < 3; k++){
            if (totalSemua[k] > maxTotal){
                maxTotal = totalSemua[k];
                cabangTertinggi=cabang[k];
            }
        }
        System.out.printf("Total penjualan tertinggi adalah cabang %s dengan pemasukan sebanyak Rp. %d\n",cabangTertinggi,maxTotal );
    }
}