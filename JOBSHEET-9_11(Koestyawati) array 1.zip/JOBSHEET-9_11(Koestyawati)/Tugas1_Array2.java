public class Tugas1_Array2{
    public static void main(String[] args) {
        char[] karakter = {'K', 'o', 'e', 's', 't', 'y', 'a', 'w', 'a', 't', 'i'};
        char[][] nama = new char[8][5];

        for (int i = 0; i < nama.length; i++){
            for (int j = 0; j < nama[0].length; j++){
                if ((i*nama[0].length+j) % karakter.length == (i*nama[0].length+j) % karakter.length){
                    nama[i][j] = karakter[(i*nama[0].length+j) % karakter.length];
                    }
                }
            }
        for (int i = 0; i < nama.length; i++){
            for (int j = 0; j < nama[0].length; j++){
                System.out.print(nama[i][j] + " ");
            }
            System.out.println("");
        }
    }
}