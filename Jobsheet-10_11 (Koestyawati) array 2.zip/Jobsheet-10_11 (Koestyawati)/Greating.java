import java.util.Scanner;

public class Greating{
	
static void beriSalam(){
	System.out.println("Halo Selamat Pagi");
}

public static void main(String[] args){
	beriSalam();
}

}