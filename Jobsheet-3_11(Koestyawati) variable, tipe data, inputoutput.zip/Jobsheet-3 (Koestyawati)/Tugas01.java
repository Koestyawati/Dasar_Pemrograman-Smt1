public class Tugas01{

	public static void main(String[] args){
		char kelas = 'Z';
		String kampus = "polinema";
		byte tingkat = 1;
		boolean statusSkill = true;
		byte bilanganBulat = 10;
		double bilanganPecahan = 3.33333;
		char karakter = 'C';
		System.out.println("Saya mahasiswa " + kampus + "kelas " + tingkat + "kelas");
		System.out.println("Saya masuk " + kampus + "saya " + statusSkill + "Sudah menguasai programing ");
		System.out.println("Saya sedang belajar menampilkan nilai: ");
		System.out.println("Bilangan bulat " + bilanganBulat);
		System.out.println("Bilangan pecahan " + bilanganPecahan);
		System.out.println("Karakter " + karakter);
	}
}