public class ContohVariabel11{

	public static void main(String[] args){
		String salahSatuHobySayaAdalah = "Rebahan";
        boolean isPandai = true;
        char jenisKelamin = 'P';
        byte _umurSayaSekarang = 18;
        double $ipk = 3.24, tinggi = 1.78;
    	System.out.println(salahSatuHobySayaAdalah);
		System.out.println("Apakah pandai? " + isPandai);
		System.out.println("Jenis kelamin: " + jenisKelamin);
		System.out.println("Umurku Saat ini: " + _umurSayaSekarang);
		System.out.println(String.format("Saya beripk %s, dengan tinggi badan %s", $ipk, tinggi));
	}
}
