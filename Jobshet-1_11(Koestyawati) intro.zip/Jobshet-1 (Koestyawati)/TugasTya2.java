public class  TugasTya2 {
	
	public static void main (String[] args) {

		System.out.println("-----------------------------------------------") ;
		System.out.println("Biodata Mahasiswa Jurusan Teknologi Informasi") ;
		System.out.println("-----------------------------------------------") ;
		System.out.println("Nama   : Koestyawati") ;
		System.out.println("Nim    : 22231750002") ;
		System.out.println("Alamat : Ds.penompo Dsn.sukorame Kec.Jetis Kab.Mojokerto") ;
		System.out.println("No HP  : 088217143157") ;
		System.out.println("Hobi   : scroll tik tok") ;
		System.out.println("------------------------------------------------") ;

}
} 
